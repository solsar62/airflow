# airflow_intro
Ejemplos de DAGs para ser ejecutados en Airflow (Google Cloud Composer)
